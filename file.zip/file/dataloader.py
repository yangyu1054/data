import tensorflow as tf
import os

from tensorflow.python.ops import array_ops, math_ops
import cv2

class DataLoader(object):
    """Data Loader for the SR GAN, that prepares a tf data object for training."""

    def __init__(self, image_dir_hdr, image_dir_sdr, hdr_image_size, sdr_image_size):
        """
        Initializes the dataloader.
        Args:
            image_dir: The path to the directory containing high resolution images.
            hr_image_size: Integer, the crop size of the images to train on (High
                           resolution images will be cropped to this width and height).
        Returns:
            The dataloader object.
        """
        self.image_paths_hdr = [os.path.join(image_dir_hdr, x) for x in os.listdir(image_dir_hdr)]
        self.image_paths_sdr = [os.path.join(image_dir_sdr, x) for x in os.listdir(image_dir_sdr)]
        self.hdr_image_size = hdr_image_size
        self.sdr_image_size = sdr_image_size

    def _parse_image_sdr(self, image_path):
        """
        Function that loads the images given the path.
        Args:
            image_path: Path to an image file.
        Returns:
            image: A tf tensor of the loaded image.
        """

        image_path = image_path.numpy().decode('utf-8')
        # image = cv2.imread(image_path, cv2.IMREAD_ANYCOLOR | cv2.IMREAD_ANYDEPTH)
        image = cv2.imread(image_path, cv2.IMREAD_ANYCOLOR | cv2.IMREAD_ANYDEPTH)
        image = tf.convert_to_tensor(image, tf.float32)

        # Check if image is large enough
        if tf.keras.backend.image_data_format() == 'channels_last':
            shape = array_ops.shape(image)[:2]
        else:
            shape = array_ops.shape(image)[1:]
        cond = math_ops.reduce_all(shape >= tf.constant(self.sdr_image_size))

        image = tf.cond(cond, lambda: tf.identity(image),
                        lambda: tf.image.resize(image, [self.sdr_image_size, self.sdr_image_size]))

        return image

    def _parse_image_hdr(self, image_path):
        """
        Function that loads the images given the path.
        Args:
            image_path: Path to an image file.
        Returns:
            image: A tf tensor of the loaded image.
        """

        image_path = image_path.numpy().decode('utf-8')
        image = cv2.imread(image_path, cv2.IMREAD_ANYCOLOR | cv2.IMREAD_ANYDEPTH)
        print(image.shape)
        image = tf.convert_to_tensor(image, tf.float32)

        # Check if image is large enough
        if tf.keras.backend.image_data_format() == 'channels_last':
            shape = array_ops.shape(image)[:2]
        else:
            shape = array_ops.shape(image)[1:]
        cond = math_ops.reduce_all(shape >= tf.constant(self.hdr_image_size))

        image = tf.cond(cond, lambda: tf.identity(image),
                        lambda: tf.image.resize(image, [self.hdr_image_size, self.hdr_image_size]))

        return image

    def _crop_hdr(self, image):
        """
        Function that crops the image according a defined width
        and height.
        Args:
            image: A tf tensor of an image.
        Returns:
            image: A tf tensor of containing the cropped image.
        """
        image = tf.image.crop_to_bounding_box(image, 0, 0, self.hdr_image_size, self.hdr_image_size)
        return image



    def _crop_sdr(self, image):
        """
        Function that crops the image according a defined width
        and height.
        Args:
            image: A tf tensor of an image.
        Returns:
            image: A tf tensor of containing the cropped image.
        """
        image = tf.image.crop_to_bounding_box(image, 0, 0, self.sdr_image_size, self.sdr_image_size)
        return image

    def _high_low_res_pairs(self, high_res):
        """
        Function that generates a low resolution image given the 
        high resolution image. The downsampling factor is 4x.
        Args:
            high_res: A tf tensor of the high res image.
        Returns:
            low_res: A tf tensor of the low res image.
            high_res: A tf tensor of the high res image.
        """

        low_res = tf.image.resize(high_res, 
                                  [self.image_size // 4, self.image_size // 4], 
                                  method='bicubic')

        return low_res, high_res

    def _rescale(self, low_res, high_res):
        """
        Function that rescales the pixel values to the -1 to 1 range.
        For use with the generator output tanh function.
        Args:
            low_res: The tf tensor of the low res image.
            high_res: The tf tensor of the high res image.
        Returns:
            low_res: The tf tensor of the low res image, rescaled.
            high_res: the tf tensor of the high res image, rescaled.
        """
        high_res = high_res * 2.0 - 1.0

        return low_res, high_res

    def dataset(self, batch_size=2, threads=4):
        """
        Returns a tf dataset object with specified mappings.
        Args:
            batch_size: Int, The number of elements in a batch returned by the dataset.
            threads: Int, CPU threads to use for multi-threaded operation.
        Returns:
            dataset: A tf dataset object.
        """

        # Generate tf dataset from high res image paths.
        dataset_hdr = tf.data.Dataset.from_tensor_slices(self.image_paths_hdr)
        dataset_sdr = tf.data.Dataset.from_tensor_slices(self.image_paths_sdr)

        # Read the images
        dataset_hdr = dataset_hdr.map(lambda x: tf.py_function(func=self._parse_image_hdr, inp=[x], Tout=tf.float32))
        dataset_sdr = dataset_sdr.map(lambda x: tf.py_function(func=self._parse_image_sdr, inp=[x], Tout=tf.float32))


        # Crop out a piece for training
        dataset_hdr = dataset_hdr.map(self._crop_hdr, num_parallel_calls=tf.data.experimental.AUTOTUNE)
        dataset_sdr = dataset_sdr.map(self._crop_sdr, num_parallel_calls=tf.data.experimental.AUTOTUNE)

        # Generate low resolution by downsampling crop.
        dataset = tf.data.Dataset.zip((dataset_hdr, dataset_sdr)) 

        # Rescale the values in the input
        dataset = dataset.map(self._rescale, num_parallel_calls=tf.data.experimental.AUTOTUNE)

        # Batch the input, drop remainder to get a defined batch size.
        # Prefetch the data for optimal GPU utilization.
        dataset = dataset.shuffle(30).batch(batch_size, drop_remainder=True).prefetch(tf.data.experimental.AUTOTUNE)

        return dataset
        return dataset_hdr


